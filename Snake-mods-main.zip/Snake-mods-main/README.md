# Snake-mods
mods for the google snake game!

to use, import book mark and then when u are on the google snake page, click it!
